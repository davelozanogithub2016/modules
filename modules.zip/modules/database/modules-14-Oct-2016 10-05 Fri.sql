DROP TABLE IF EXISTS generated_tbl;

CREATE TABLE `generated_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `case_link` varchar(255) NOT NULL,
  `require_link` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO generated_tbl VALUES("1","infinixcherrymobile@gmail.com","$2y$104A339G5365590ifia68hC35b1i3d6A2744A4094fchH2Gi66hf7hEa38e5ehg","pages/generated/d8805fc57a6f0435df60590ac69f371b.php");
INSERT INTO generated_tbl VALUES("2","CabugaCabuga@yahoo.com","$2y$10e71d61CB543F6BeF5d9110i1BFaB0g9288iii46F9FAg7iaA343Bh0d21HiB4","pages/generated/d3767776763f907e815e130e62cd7c9f.php");
INSERT INTO generated_tbl VALUES("3","cabugajeddahlyn@gmail.com","$2y$1006f6aH1184cG3118F59163EC3bd3BAhB21di93g6c453hBi6iF632H432fbG1","pages/generated/fd707fed00ea122e2ef453e66e636e4e.php");
INSERT INTO generated_tbl VALUES("4","cabugajeddahlyn@gmail.com","$2y$10AgFi341iBi150bGhDiaH191C887D448AcC0F5hai5b6dhciF8g7422Ai9h9bD","pages/generated/632de19c7e3fdf0f52ba2ef80dd813a9.php");
INSERT INTO generated_tbl VALUES("5","Lozano@gmail.com","$2y$1012148CEc99024dCi8hDG1gC1f4GFg3Bb90eb1642B1c613iCcb46D4C863A3g","pages/generated/f81b7e2a4b1b04256efdec134d1cf928.php");
INSERT INTO generated_tbl VALUES("6","administrator@yahoo.com","$2y$10808b3E69FeaE1h42eDHH2ff12B5Ab9523E329832EcCg3b2g9abgfci21Fb71","pages/generated/dee7deb3a394f0695ab5db148136fa02.php");



DROP TABLE IF EXISTS members_tbl;

CREATE TABLE `members_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `surname` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `middlename` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `security_code` varchar(255) NOT NULL,
  `role` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO members_tbl VALUES("6","Administrator","Administrator","Administrator","administrator@yahoo.com","09999999992","Administrator","Administrator","$2y$10$6C5fcJ36qW7zFEVz01sKJ.uuE/AE600Uwhb6oeXOWw3mERiqirN5e","706624","0","Activated","2016-10-14 01:04:13");



DROP TABLE IF EXISTS security_tbl;

CREATE TABLE `security_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `security` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO security_tbl VALUES("2","ssl");



DROP TABLE IF EXISTS smtp_server_tbl;

CREATE TABLE `smtp_server_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `smtp_socket` varchar(255) NOT NULL,
  `smtp_security` varchar(255) NOT NULL,
  `smtp_email` varchar(255) NOT NULL,
  `smtp_password` varchar(255) NOT NULL,
  `smtp_from` varchar(255) NOT NULL,
  `smtp_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS socket_tbl;

CREATE TABLE `socket_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `socket` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO socket_tbl VALUES("3","smtp.gmail.com:465");



