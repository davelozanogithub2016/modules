<?php
include 'functions/functions.php';
admin_logout();
