<?php
include 'functions/functions.php';
member_logout();
