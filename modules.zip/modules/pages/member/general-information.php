<?php 
include 'functions/functions.php';
if(!isset($_SESSION['user'])){
header("Location: login");
}
$query 	= $db->query("SELECT * FROM members_tbl WHERE id = ".$_SESSION['user']." ");
$row 	= $query->fetch_object();
$role 	= $row->role;
switch ($role) {
	case 2:
	$roles = 'member';
	break;
	
	default:
	# code...
	break;
}
?>
<html>
<head>
	<title>Compiled Modules</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

	<div class="main-container">

		<div class="logo-container">
			<img src="images/logo.png">
		</div>

		<div class="nav-container">
			<ul>
				<li class="active"><a href="general-information">general information</a></li>
				<li><a href="member-logout">logout</a></li>
			</ul>
		</div>

	</div>

		<div class="body-container">
			<h1>Hi! I'm <?php echo$roles?></h1>
		</div>

		<div class="footer">
			<p> Compiled Modules @ <?php echo date('Y')?> </p>
		</div>

</body>
</html>
