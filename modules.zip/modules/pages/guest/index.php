<?php    
    $PNG_WEB_DIR = 'pages/guest/temp/';
    include "lib/qrlib.php";    
    if (!file_exists('pages/guest/temp/'))
        mkdir('pages/guest/temp/');
    $filename = 'pages/guest/temp/test.png';
    $errorCorrectionLevel = 'L';
    if (isset($_REQUEST['level']) && in_array($_REQUEST['level'], array('L','M','Q','H')))
        $errorCorrectionLevel = $_REQUEST['level'];    
    $matrixPointSize = 4;
    if (isset($_REQUEST['size']))
        $matrixPointSize = min(max((int)$_REQUEST['size'], 1), 10);
    if (isset($_REQUEST['data'])) { 
        if (trim($_REQUEST['data']) == '')
            die('data cannot be empty! <a href="?">back</a>');
        $filename = 'pages/guest/temp/'.md5($_REQUEST['data'].'|'.$errorCorrectionLevel.'|'.$matrixPointSize).'.png';
        QRcode::png($_REQUEST['data'], $filename, $errorCorrectionLevel, $matrixPointSize, 2);    
    } else {    
        QRcode::png('PHP QR Code :)', $filename, $errorCorrectionLevel, $matrixPointSize, 2);    
    }    
    echo '<img src="'.$PNG_WEB_DIR.basename($filename).'" /><hr/>';  
    echo '
        <form  method="POST">
        <input name="data" value="'.(isset($_REQUEST['data'])?htmlspecialchars($_REQUEST['data']):'PHP QR Code :)').'" />
        <input type="hidden" name="level" value="H">
        <input type="hidden" name="size" value="4">
        <input type="submit" value="GENERATE">
        </form>
        ';